import boto3

def handler(event, context):
    ec2 = boto3.client('ec2')
    ami_ids = event['ami_ids']
    
    for ami_id in ami_ids:
        ec2.deregister_image(ImageId=ami_id)
    
    return {
        'statusCode': 200,
        'body': 'AMIs deregistered successfully!'
    }
